# Phantom Menu - add your own pictures to the Workshop version. Made by Ares.
# Put this "Phantom Pictures" folder inside  cod25\kronos\mods\phantom_menu  and run
# "Install Phantom Pictures.bat". Restart the game afterwards (pictures load when the game starts).
#   Icons\Level 7, Icons\Prestige 3, Icons\Prestige Master 12 (levels 270-293) ...
#                       one PNG per folder = that icon                       256 x 256
#   Backgrounds         any name (preset names aether, waw, bo1, bo2, bo3, bo4, cw, bo6
#                       become that preset's background)                     720 x 1080
#   Gun Pictures        named after the gun ID, e.g. sat_ar_kiwi.png         512 x 256
#   Enemy Pictures      named after the enemy ID, e.g. sat_spawner_zombie_karkinos_ob.png  512 x 256
# Other sizes are fitted automatically. The menu only shows pictures this tool has installed,
# so always add pictures with it (it also updates the menu's picture lists).
# Undo: delete the picture from its folder here AND the matching file in ..\images, run it again.

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$mod = Split-Path -Parent $here
$images = Join-Path $mod "images"
$lua = Join-Path $mod "lua\phantom_menu_post.lua"
$pages = Join-Path $mod "scripts\zm_zz_devmenu_pages.gsc"
Add-Type -AssemblyName System.Drawing
function Say($t) { Write-Host $t }
if (-not (Test-Path $images) -or -not (Test-Path $lua) -or -not (Test-Path $pages)) {
  Say "Can't find the menu. Put this 'Phantom Pictures' folder inside cod25\kronos\mods\phantom_menu"
  exit 1
}
function IsPng($path) {
  $b = [System.IO.File]::ReadAllBytes($path)
  return ($b.Length -gt 8 -and $b[0] -eq 0x89 -and $b[1] -eq 0x50 -and $b[2] -eq 0x4E -and $b[3] -eq 0x47)
}
# fit: whole picture inside W x H with see-through edges; cover: fills W x H, edges cut off
function SavePic($src, $dst, $W, $H, $cover) {
  $img = [System.Drawing.Image]::FromFile($src)
  try {
    if ($img.Width -eq $W -and $img.Height -eq $H) { Copy-Item $src $dst -Force; return $null }
    if ($cover) { $scale = [Math]::Max($W / $img.Width, $H / $img.Height) } else { $scale = [Math]::Min($W / $img.Width, $H / $img.Height) }
    $dw = [int][Math]::Round($img.Width * $scale); $dh = [int][Math]::Round($img.Height * $scale)
    $bmp = New-Object System.Drawing.Bitmap $W, $H, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.Clear([System.Drawing.Color]::Transparent)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.DrawImage($img, [int](($W - $dw) / 2), [int](($H - $dh) / 2), $dw, $dh)
    $g.Dispose()
    $bmp.Save($dst, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    return "$($img.Width)x$($img.Height) -> ${W}x${H}"
  } finally { $img.Dispose() }
}
function CleanName($n) { return (($n.ToLower() -replace '[^a-z0-9_]', '_') -replace '_+', '_').Trim('_') }
function Pngs($dir) {
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null; return ,@() }
  $list = @()
  foreach ($p in (Get-ChildItem -Path $dir -File | Where-Object { $_.Extension -ieq ".png" } | Sort-Object Name)) {
    if (IsPng $p.FullName) { $list += $p } else { Say "  skipped $($p.Name): not a real PNG (save it as PNG in Paint)" }
  }
  return ,$list
}
$n = 0

# ---- icons: one folder per icon
$iconDir = Join-Path $here "Icons"
$dirs = @()
for ($i = 1; $i -le 55; $i++) { $dirs += ,@("Level $i", "pi_lvl_$i") }
for ($i = 1; $i -le 10; $i++) { $dirs += ,@("Prestige $i", "pi_prestige_$i") }
for ($t = 1; $t -le 41; $t++) {
  $from = [int][Math]::Ceiling(($t - 1) * 1000 / 41) + 1; $to = [int][Math]::Ceiling($t * 1000 / 41)
  $dirs += ,@("Prestige Master $t (levels $from-$to)", "pi_mtier_$t")
}
foreach ($d in $dirs) {
  $p = (Pngs (Join-Path $iconDir $d[0])) | Select-Object -First 1
  if (-not $p) { continue }
  $r = SavePic $p.FullName (Join-Path $images "$($d[1]).png") 256 256 $false
  Say "  icon $($d[0]) <- $($p.Name)$(if ($r) { " ($r)" })"
  $n++
}
# ---- backgrounds
foreach ($p in (Pngs (Join-Path $here "Backgrounds"))) {
  $b = CleanName $p.BaseName
  if ($b -notmatch '^bg_') { $b = "bg_" + $b }
  $r = SavePic $p.FullName (Join-Path $images "$b.png") 720 1080 $true
  Say "  background $($p.Name) -> $b$(if ($r) { " ($r)" })"
  $n++
}
# ---- gun pictures
foreach ($p in (Pngs (Join-Path $here "Gun Pictures"))) {
  $b = (CleanName $p.BaseName) -replace '^gp_', '' -replace '^sat_', '' -replace '_mp$', '' -replace '_zm$', ''
  if ($b -notmatch '^(ar|sm|lm|sh|dm|sn|pi|la|me|ww)_[a-z0-9_]+$') { Say "  skipped $($p.Name): name it after the gun ID, e.g. sat_ar_kiwi.png"; continue }
  $r = SavePic $p.FullName (Join-Path $images "gp_$b.png") 512 256 $false
  Say "  gun $($p.Name) -> gp_$b$(if ($r) { " ($r)" })"
  $n++
}
# ---- enemy pictures
foreach ($p in (Pngs (Join-Path $here "Enemy Pictures"))) {
  $b = (CleanName $p.BaseName) -replace '^zp_', ''
  if ($b -notmatch '^sat_spawner_') { Say "  skipped $($p.Name): name it after the enemy ID, e.g. sat_spawner_zombie_karkinos_ob.png"; continue }
  $r = SavePic $p.FullName (Join-Path $images "zp_$b.png") 512 256 $false
  Say "  enemy $($p.Name) -> zp_$b$(if ($r) { " ($r)" })"
  $n++
}

# ---- tell the menu which pictures exist
$utf8 = New-Object System.Text.UTF8Encoding $false
$slots = @($dirs | ForEach-Object { $_[1] })
$have = @($slots | Where-Object { Test-Path (Join-Path $images "$_.png") })
if ($have.Count -eq $slots.Count) { $val = "*" } elseif ($have.Count -eq 0) { $val = "" } else { $val = "|" + ($have -join "|") + "|" }
$t = [System.IO.File]::ReadAllText($lua)
$t = [regex]::Replace($t, 'local MY_ICONS = "[^"]*" -- MY_ICONS', ('local MY_ICONS = "' + $val + '" -- MY_ICONS'))
[System.IO.File]::WriteAllText($lua, $t, $utf8)

# GSC strings may be at most ~200 characters, so long lists are built from pieces
function SetPagesKey($text, $key, $value) {
  $lines = $text -split "`n"
  $out = New-Object System.Collections.Generic.List[string]
  $done = $false
  foreach ($l in $lines) {
    if ($l -match ('^\s*level\.zm_dmp\["' + [regex]::Escape($key) + '"\]')) {
      if (-not $done) {
        $done = $true
        $parts = @(); for ($i = 0; $i -lt [Math]::Max(1, $value.Length); $i += 200) { $parts += $value.Substring($i, [Math]::Min(200, $value.Length - $i)) }
        if ($value.Length -eq 0) { $parts = @("") }
        $out.Add('    level.zm_dmp["' + $key + '"] = "' + $parts[0] + '";')
        for ($i = 1; $i -lt $parts.Count; $i++) { $out.Add('    level.zm_dmp["' + $key + '"] = level.zm_dmp["' + $key + '"] + "' + $parts[$i] + '";') }
      }
      continue
    }
    $out.Add($l)
  }
  return ($out -join "`n")
}
$bgs = @("phantom_bg", "bg_aether", "bg_waw", "bg_bo1", "bg_bo2", "bg_bo3", "bg_bo4", "bg_cw", "bg_bo6") | Where-Object { Test-Path (Join-Path $images "$_.png") }
foreach ($f in (Get-ChildItem -Path $images -File -Filter "bg_*.png" | Sort-Object Name)) { if ($bgs -notcontains $f.BaseName) { $bgs += $f.BaseName } }
$gp = @(Get-ChildItem -Path $images -File -Filter "gp_*.png" | Sort-Object Name | ForEach-Object { $_.BaseName })
$zp = @(Get-ChildItem -Path $images -File -Filter "zp_*.png" | Sort-Object Name | ForEach-Object { $_.BaseName })
$g = ([System.IO.File]::ReadAllText($pages)) -replace "`r", ""
$g = SetPagesKey $g "bg_list" ($bgs -join "|")
$g = SetPagesKey $g "gunpics" ("|" + ($gp -join "|") + "|")
$g = SetPagesKey $g "zpics" ("|" + ($zp -join "|") + "|")
[System.IO.File]::WriteAllText($pages, $g, $utf8)

Say ""
if ($n -eq 0) { Say "No new pictures. Lists updated. Drop PNGs into the folders here, then run this again." }
else { Say "Done: $n pictures installed. Restart the game to see them." }
