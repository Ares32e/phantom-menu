@echo off
title Phantom Menu - Install Phantom Pictures
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install Phantom Pictures.ps1"
echo.
pause
